
import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>EHC - Ethical Hacking Community</title>
        <meta name="description" content="Welcome to the Ethical Hacking Community website." />
      </Head>
      <main className="p-8 text-center">
        <h1 className="text-4xl font-bold">Welcome to EHC</h1>
        <p className="mt-4 text-lg">We promote ethical hacking knowledge and training.</p>
        <div className="mt-10">
          <h2 className="text-2xl font-semibold">Client Reviews</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            {/* Static image samples */}
            <img src="/reviews/review1.jpg" alt="Review 1" className="rounded shadow" />
            <img src="/reviews/review2.jpg" alt="Review 2" className="rounded shadow" />
            <img src="/reviews/review3.jpg" alt="Review 3" className="rounded shadow" />
          </div>
        </div>
      </main>
    </>
  );
}
